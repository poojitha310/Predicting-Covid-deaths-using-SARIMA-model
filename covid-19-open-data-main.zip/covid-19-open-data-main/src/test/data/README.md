Sampled tables from production data as of June 12

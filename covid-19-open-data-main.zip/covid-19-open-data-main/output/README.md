# Output

When the data extraction pipeline is executed locally, output files will be placed here. Please see
the [documentation](../README.md) for the URL where the output files can be located, since they are
too large to be stored on GitHub.
